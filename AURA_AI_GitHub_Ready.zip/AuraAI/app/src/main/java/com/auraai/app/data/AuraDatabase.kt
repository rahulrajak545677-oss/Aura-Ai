package com.auraai.app.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "memories")
data class MemoryEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val text: String, val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "conversations")
data class ConversationEntity(@PrimaryKey val id: String, val title: String, val createdAt: Long = System.currentTimeMillis(), val updatedAt: Long = System.currentTimeMillis(), val pinned: Boolean = false)

@Entity(tableName = "messages", indices = [Index("conversationId")])
data class MessageEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val conversationId: String, val fromUser: Boolean, val text: String, val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "tasks", indices = [Index("dueAt")])
data class TaskEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val detail: String = "", val dueAt: Long? = null, val completed: Boolean = false, val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "saved_assets")
data class SavedAssetEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val label: String, val uri: String, val mimeType: String = "", val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "project_notes")
data class ProjectNoteEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val projectId: Long, val title: String, val body: String, val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "projects")
data class ProjectEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val description: String = "", val createdAt: Long = System.currentTimeMillis())

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY createdAt DESC") fun observeAll(): Flow<List<MemoryEntity>>
    @Insert suspend fun insert(memory: MemoryEntity)
    @Delete suspend fun delete(memory: MemoryEntity)
    @Query("DELETE FROM memories") suspend fun clear()
}


@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY pinned DESC, updatedAt DESC") fun observeAll(): Flow<List<ConversationEntity>>
    @Query("SELECT * FROM conversations WHERE id = :conversationId LIMIT 1") suspend fun get(conversationId: String): ConversationEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(conversation: ConversationEntity)
    @Query("UPDATE conversations SET title = :title WHERE id = :conversationId") suspend fun rename(conversationId: String, title: String)
    @Query("UPDATE conversations SET pinned = :pinned WHERE id = :conversationId") suspend fun setPinned(conversationId: String, pinned: Boolean)
    @Query("UPDATE conversations SET updatedAt = :timestamp WHERE id = :conversationId") suspend fun touch(conversationId: String, timestamp: Long = System.currentTimeMillis())
    @Query("DELETE FROM conversations WHERE id = :conversationId") suspend fun delete(conversationId: String)
}


@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY createdAt ASC") fun observeForConversation(conversationId: String): Flow<List<MessageEntity>>
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY createdAt ASC") suspend fun getForConversation(conversationId: String): List<MessageEntity>
    @Insert suspend fun insert(message: MessageEntity)
    @Query("DELETE FROM messages WHERE conversationId = :conversationId") suspend fun deleteForConversation(conversationId: String)
}


@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY completed ASC, dueAt ASC, createdAt DESC") fun observeAll(): Flow<List<TaskEntity>>
    @Insert suspend fun insert(task: TaskEntity): Long
    @Update suspend fun update(task: TaskEntity)
    @Delete suspend fun delete(task: TaskEntity)
    @Query("UPDATE tasks SET completed = :completed WHERE id = :id") suspend fun setCompleted(id: Long, completed: Boolean)
}

@Dao
interface SavedAssetDao {
    @Query("SELECT * FROM saved_assets ORDER BY createdAt DESC") fun observeAll(): Flow<List<SavedAssetEntity>>
    @Insert suspend fun insert(asset: SavedAssetEntity)
    @Delete suspend fun delete(asset: SavedAssetEntity)
}


@Dao
interface ProjectNoteDao {
    @Query("SELECT * FROM project_notes WHERE projectId = :projectId ORDER BY createdAt DESC") fun observeForProject(projectId: Long): Flow<List<ProjectNoteEntity>>
    @Insert suspend fun insert(note: ProjectNoteEntity)
    @Delete suspend fun delete(note: ProjectNoteEntity)
}


@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY createdAt DESC") fun observeAll(): Flow<List<ProjectEntity>>
    @Insert suspend fun insert(project: ProjectEntity)
    @Delete suspend fun delete(project: ProjectEntity)
}


@Database(entities = [MemoryEntity::class, ProjectEntity::class, ConversationEntity::class, MessageEntity::class, TaskEntity::class, SavedAssetEntity::class, ProjectNoteEntity::class], version = 3, exportSchema = true)
abstract class AuraDatabase : RoomDatabase() {
    abstract fun memoryDao(): MemoryDao
    abstract fun projectDao(): ProjectDao
    abstract fun taskDao(): TaskDao
    abstract fun savedAssetDao(): SavedAssetDao
    abstract fun projectNoteDao(): ProjectNoteDao
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS conversations (id TEXT NOT NULL PRIMARY KEY, title TEXT NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, pinned INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, conversationId TEXT NOT NULL, fromUser INTEGER NOT NULL, text TEXT NOT NULL, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_messages_conversationId ON messages (conversationId)")
            }
        }
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, title TEXT NOT NULL, detail TEXT NOT NULL, dueAt INTEGER, completed INTEGER NOT NULL, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_tasks_dueAt ON tasks (dueAt)")
                db.execSQL("CREATE TABLE IF NOT EXISTS saved_assets (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, label TEXT NOT NULL, uri TEXT NOT NULL, mimeType TEXT NOT NULL, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS project_notes (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, projectId INTEGER NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL, createdAt INTEGER NOT NULL)")
            }
        }
        @Volatile private var INSTANCE: AuraDatabase? = null
        fun get(context: Context): AuraDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AuraDatabase::class.java, "aura_local.db").addMigrations(MIGRATION_1_2, MIGRATION_2_3).build().also { INSTANCE = it }
        }
    }
}
