package com.auraai.app.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

data class WebResult(val title: String, val url: String, val description: String)

/** Brave Search adapter. Requires a user-provided Brave Search API key. */
class BraveSearchClient {
    suspend fun search(apiKey: String, query: String): List<WebResult> = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) { "Add a Brave Search API key in AURA settings to use web search." }
        require(query.isNotBlank()) { "Enter something to search for." }
        val encoded = URLEncoder.encode(query, "UTF-8")
        val connection = (URL("https://api.search.brave.com/res/v1/web/search?q=$encoded&count=8").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("X-Subscription-Token", apiKey)
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val payload = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("Web search failed ($code). Check your key or quota.")
            val web = JSONObject(payload).optJSONObject("web")?.optJSONArray("results") ?: return@withContext emptyList()
            buildList {
                for (i in 0 until web.length()) {
                    val item = web.optJSONObject(i) ?: continue
                    val title = item.optString("title").trim()
                    val url = item.optString("url").trim()
                    if (title.isNotBlank() && url.startsWith("https://")) add(WebResult(title, url, item.optString("description")))
                }
            }
        } finally { connection.disconnect() }
    }
}
