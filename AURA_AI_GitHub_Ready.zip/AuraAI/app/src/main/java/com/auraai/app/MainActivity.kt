package com.auraai.app

import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import java.util.Locale
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.auraai.app.overlay.FloatingAssistantService
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.auraai.app.network.GeminiClient
import kotlinx.coroutines.launch
import com.auraai.app.data.AuraDatabase
import com.auraai.app.data.MemoryEntity
import com.auraai.app.data.ProjectEntity
import com.auraai.app.data.ConversationEntity
import com.auraai.app.data.MessageEntity
import com.auraai.app.data.TaskEntity
import java.util.UUID

private val Navy = Color(0xFF080D18)
private val SurfaceDark = Color(0xFF101827)
private val CardDark = Color(0xFF172234)
private val Blue = Color(0xFF299BFF)
private val Teal = Color(0xFF43DCC5)
private val Muted = Color(0xFF98A7BC)
private val TextMain = Color(0xFFF3F6FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("aura_prefs", MODE_PRIVATE)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Navy, surface = SurfaceDark)) {
                AuraApp(prefs.getString("gemini_key", "") ?: "", prefs.getString("brave_key", "") ?: "", onSaveKey = { prefs.edit().putString("gemini_key", it).apply() }, onSaveBraveKey = { prefs.edit().putString("brave_key", it).apply() })
            }
        }
    }
}


@Composable
private fun AuraApp(initialKey: String, initialBraveKey: String, onSaveKey: (String) -> Unit, onSaveBraveKey: (String) -> Unit) {
    var tab by remember { mutableStateOf("Home") }
    var apiKey by remember { mutableStateOf(initialKey) }
    var braveKey by remember { mutableStateOf(initialBraveKey) }
    var showSettings by remember { mutableStateOf(false) }
    Scaffold(containerColor = Navy, bottomBar = {
        NavigationBar(containerColor = SurfaceDark, contentColor = TextMain) {
            listOf("Home", "Chat", "Create", "Memory", "Profile").forEach { label ->
                NavigationBarItem(selected = tab == label, onClick = { tab = label }, icon = {
                    Icon(when(label){ "Home"->Icons.Default.Home; "Chat"->Icons.Default.Chat; "Create"->Icons.Default.AutoAwesome; "Memory"->Icons.Default.Bookmark; else->Icons.Default.Person }, label)
                }, label = { Text(label) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Blue, selectedTextColor = Blue, indicatorColor = Color(0xFF20334B), unselectedIconColor = Muted, unselectedTextColor = Muted))
            }
        }
    }) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when(tab) {
                "Home" -> HomeScreen(onChat = { tab = "Chat" }, onCreate = { tab = "Create" }, onSettings = { showSettings = true }, onVoice = { tab = "Voice" }, onSearch = { tab = "Search" }, onTasks = { tab = "Tasks" })
                "Chat" -> ChatScreen(apiKey)
                "Search" -> WebSearchScreen(braveKey)
                "Voice" -> VoiceAssistantScreen(apiKey)
                "Tasks" -> TaskPlannerScreen()
                "Create" -> ProjectsScreen()
                "Memory" -> MemoryVaultScreen()
                else -> SimpleScreen("Profile & Settings", "Configure AURA AI and provider settings.", Icons.Default.Settings, onSettings = { showSettings = true })
            }
            if (showSettings) AlertDialog(onDismissRequest = { showSettings = false }, containerColor = CardDark, title = { Text("Gemini setup", color = TextMain) }, text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Development setup only", color = Muted)
                    OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("Gemini API key") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
                    OutlinedTextField(value = braveKey, onValueChange = { braveKey = it }, label = { Text("Brave Search API key (optional)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
                    Text("Web search uses Brave Search and requires a separate API key. Search is not enabled until you add one.", color = Muted, fontSize = 12.sp)
                    Text("Do not ship an APK with a personal API key embedded or exposed. A secure backend proxy is planned.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {
                        showSettings = false
                        if (!Settings.canDrawOverlays(this@MainActivity)) {
                            val permissionIntent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                            startActivity(permissionIntent)
                        } else {
                            ContextCompat.startForegroundService(this@MainActivity, Intent(this@MainActivity, FloatingAssistantService::class.java))
                        }
                    }, colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text("Enable floating bubble") }
                    Text("After granting overlay permission, return to the app and tap Enable floating bubble again.", color = Muted, fontSize = 11.sp)
                }
            }, confirmButton = { TextButton(onClick = { onSaveKey(apiKey); onSaveBraveKey(braveKey); showSettings = false }) { Text("Save", color = Blue) } }, dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel", color = Muted) } })
        }
    }
}



@Composable
private fun VoiceAssistantScreen(apiKey: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var recognized by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val tts = remember { TextToSpeech(context) { } }
    DisposableEffect(Unit) { onDispose { tts.stop(); tts.shutdown() } }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            recognized = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (recognized.isNotBlank()) {
                busy = true; error = ""; answer = ""
                kotlinx.coroutines.MainScope().launch {
                    try { answer = GeminiClient().reply(apiKey, recognized) } catch (e: Exception) { error = e.message ?: "Voice request failed" } finally { busy = false }
                }
            }
        }
    }
    Column(Modifier.fillMaxSize().background(Navy).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("VOICE ASSISTANT", color = Teal, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(18.dp))
        Box(Modifier.size(132.dp).background(Color(0xFF17314C), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Mic, null, tint = Blue, modifier = Modifier.size(54.dp)) }
        Text("Speak to AURA", color = TextMain, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
        Text("Tap the microphone to start speech recognition. Your audio is not recorded continuously.", color = Muted)
        Button(onClick = {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to AURA AI"); putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag()) }
            try { speechLauncher.launch(intent) } catch (e: Exception) { error = "Speech recognition isn't available on this device." }
        }, colors = ButtonDefaults.buttonColors(containerColor = Blue), enabled = !busy) { Icon(Icons.Default.Mic, null); Spacer(Modifier.width(8.dp)); Text("Start listening") }
        if (recognized.isNotBlank()) Card(colors = CardDefaults.cardColors(containerColor = CardDark)) { Column(Modifier.padding(16.dp)) { Text("You said", color = Muted); Text(recognized, color = TextMain) } }
        if (busy) CircularProgressIndicator(color = Teal)
        if (answer.isNotBlank()) Card(colors = CardDefaults.cardColors(containerColor = CardDark)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("AURA", color = Teal, fontWeight = FontWeight.Bold); Text(answer, color = TextMain); Button(onClick = { tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "aura_reply") }, colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark)) { Icon(Icons.Default.VolumeUp, null); Text("Speak reply") }; TextButton(onClick = { tts.stop() }) { Text("Stop speaking", color = Muted) } } }
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF8B8B))
    }
}

@Composable
private fun HomeScreen(onChat: () -> Unit, onCreate: () -> Unit, onSettings: () -> Unit, onVoice: () -> Unit = {}, onSearch: () -> Unit = {}, onTasks: () -> Unit = {}) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val recentChats by remember { AuraDatabase.get(context).conversationDao().observeAll() }.collectAsState(initial = emptyList())
    Column(Modifier.fillMaxSize().background(Navy).padding(22.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("AURA AI", color = TextMain, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Think. Understand. Create. Assist.", color = Muted, fontSize = 12.sp)
            }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings", tint = Muted) }
        }
        Spacer(Modifier.height(18.dp))
        Text("Hello,", color = TextMain, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
        Text("What do you want to do today?", color = Muted, fontSize = 16.sp)
        Row(Modifier.fillMaxWidth().background(CardDark, RoundedCornerShape(20.dp)).clickable { onChat() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Search, null, tint = Muted)
            Spacer(Modifier.width(12.dp)); Text("Ask anything...", color = Muted, modifier = Modifier.weight(1f)); Icon(Icons.Default.ArrowForward, null, tint = Blue)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HomeTile("Chat", Icons.Default.Chat, Modifier.weight(1f), onChat)
            HomeTile("Create", Icons.Default.AutoAwesome, Modifier.weight(1f), onCreate)
            HomeTile("Image", Icons.Default.Image, Modifier.weight(1f), onCreate)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HomeTile("Voice", Icons.Default.Mic, Modifier.weight(1f), onVoice)
            HomeTile("Web Search", Icons.Default.Public, Modifier.weight(1f), onSearch)
            HomeTile("Tasks", Icons.Default.CheckCircle, Modifier.weight(1f), onTasks)
        }
        Text("Recent chats", color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        if (recentChats.isEmpty()) {
            Box(Modifier.fillMaxWidth().background(SurfaceDark, RoundedCornerShape(18.dp)).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).background(Color(0xFF213C5B), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.ChatBubbleOutline, null, tint = Blue) }
                    Spacer(Modifier.width(12.dp)); Column { Text("Start your first conversation", color = TextMain); Text("Your chats will appear here", color = Muted, fontSize = 12.sp) }
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                recentChats.take(3).forEach { chat ->
                    Row(Modifier.fillMaxWidth().background(SurfaceDark, RoundedCornerShape(16.dp)).clickable { onChat() }.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ChatBubbleOutline, null, tint = Blue); Spacer(Modifier.width(10.dp)); Text(chat.title, color = TextMain, modifier = Modifier.weight(1f), maxLines = 1); if (chat.pinned) Icon(Icons.Default.Bookmark, null, tint = Teal)
                    }
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Text("A calm space for ideas.", color = Teal, fontSize = 13.sp)
    }
}


@Composable
private fun WebSearchScreen(apiKey: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<com.auraai.app.network.WebResult>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().background(Navy).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("WEB SEARCH", color = Teal, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text("Research with sources", color = TextMain, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
        Text("Searches live web results using your Brave Search API key. Results link to their original pages.", color = Muted, fontSize = 13.sp)
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search the web...") }, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextMain, unfocusedTextColor = TextMain))
        Button(onClick = {
            loading = true; error = ""; results = emptyList()
            scope.launch {
                try { results = com.auraai.app.network.BraveSearchClient().search(apiKey, query) }
                catch (e: Exception) { error = e.message ?: "Search failed. Try again." }
                finally { loading = false }
            }
        }, enabled = !loading && query.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text(if (loading) "Searching..." else "Search") }
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF8C8C), fontSize = 13.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(results) { result ->
                Column(Modifier.fillMaxWidth().background(CardDark, RoundedCornerShape(16.dp)).clickable {
                    try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(result.url))) } catch (_: Exception) { error = "Couldn't open this link." }
                }.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(result.title, color = Blue, fontWeight = FontWeight.SemiBold)
                    if (result.description.isNotBlank()) Text(result.description, color = TextMain, fontSize = 13.sp)
                    Text(result.url, color = Teal, fontSize = 11.sp, maxLines = 1)
                }
            }
        }
    }
}


@Composable
private fun HomeTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, action: () -> Unit) {
    Column(modifier.background(SurfaceDark, RoundedCornerShape(18.dp)).clickable { action() }.padding(vertical = 18.dp).then(modifier), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = Blue, modifier = Modifier.size(25.dp)); Spacer(Modifier.height(7.dp)); Text(title, color = TextMain, fontSize = 12.sp)
    }
}

@Composable
private fun ChatScreen(apiKey: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val db = remember { AuraDatabase.get(context) }
    val chatDao = db.conversationDao()
    val messageDao = db.messageDao()
    val client = remember { GeminiClient() }
    val scope = rememberCoroutineScope()
    val chats by chatDao.observeAll().collectAsState(initial = emptyList())
    var selectedId by remember { mutableStateOf<String?>(null) }
    var input by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var renameTarget by remember { mutableStateOf<ConversationEntity?>(null) }
    var renameText by remember { mutableStateOf("") }
    val selectedChat = chats.firstOrNull { it.id == selectedId }
    val emptyMessageFlow = remember { kotlinx.coroutines.flow.flowOf(emptyList<MessageEntity>()) }
    val messageFlow = selectedId?.let { messageDao.observeForConversation(it) } ?: emptyMessageFlow
    val messages by messageFlow.collectAsState(initial = emptyList())

    Column(Modifier.fillMaxSize().background(Navy).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 10.dp)) {
            Icon(Icons.Default.AutoAwesome, null, tint = Teal); Spacer(Modifier.width(10.dp)); Text("AURA AI", color = TextMain, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f))
            TextButton(onClick = { selectedId = null; input = ""; error = "" }) { Text("New chat", color = Blue) }
        }
        if (selectedId == null) {
            OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search conversations") }, leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) })
            val filtered = chats.filter { it.title.contains(search, ignoreCase = true) }
            if (filtered.isEmpty()) Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text(if (chats.isEmpty()) "Your conversations will appear here." else "No matches found.", color = Muted) }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filtered, key = { it.id }) { chat ->
                    Row(Modifier.fillMaxWidth().background(CardDark, RoundedCornerShape(16.dp)).clickable { selectedId = chat.id }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(chat.title, color = TextMain, fontWeight = FontWeight.Medium); Text(if (chat.pinned) "Pinned conversation" else "Tap to continue", color = Muted, fontSize = 12.sp) }
                        IconButton(onClick = { scope.launch { chatDao.setPinned(chat.id, !chat.pinned) } }) { Icon(if (chat.pinned) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, "Pin", tint = if (chat.pinned) Blue else Muted) }
                        IconButton(onClick = { renameTarget = chat; renameText = chat.title }) { Icon(Icons.Default.Edit, "Rename", tint = Muted) }
                        IconButton(onClick = { scope.launch { chatDao.delete(chat.id); messageDao.deleteForConversation(chat.id) } }) { Icon(Icons.Default.Delete, "Delete", tint = Muted) }
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { selectedId = null; error = "" }) { Icon(Icons.Default.ArrowBack, "Back", tint = Muted) }
                Text(selectedChat?.title ?: "Conversation", color = TextMain, maxLines = 1, modifier = Modifier.weight(1f))
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(messages, key = { it.id }) { line ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                        Text(line.text, color = TextMain, modifier = Modifier.widthIn(max = 310.dp).background(if(line.fromUser) Color(0xFF193B60) else CardDark, RoundedCornerShape(18.dp)).padding(13.dp))
                    }
                }
                if (loading) item { Text("AURA is thinking…", color = Teal) }
                if (error.isNotBlank()) item { Text(error, color = Color(0xFFFFA6A6), fontSize = 13.sp) }
            }
            Row(Modifier.fillMaxWidth().background(CardDark, RoundedCornerShape(22.dp)).padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(input, { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Message AURA…", color = Muted) }, colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color.Transparent, focusedBorderColor = Color.Transparent, unfocusedTextColor = TextMain, focusedTextColor = TextMain), maxLines = 4)
                IconButton(enabled = !loading && input.isNotBlank(), onClick = {
                    val prompt = input.trim(); input = ""; error = ""; loading = true
                    scope.launch {
                        try {
                            val chatId = selectedId ?: UUID.randomUUID().toString().also { id ->
                                chatDao.upsert(ConversationEntity(id, prompt.take(42).ifBlank { "New conversation" }))
                                selectedId = id
                            }
                            messageDao.insert(MessageEntity(conversationId = chatId, fromUser = true, text = prompt))
                            chatDao.touch(chatId)
                            val contextMessages = messageDao.getForConversation(chatId).takeLast(12).joinToString("\n") { if (it.fromUser) "User: ${it.text}" else "Assistant: ${it.text}" }
                            val reply = client.reply(apiKey, "You are AURA AI, a calm, thoughtful, helpful assistant. Reply naturally. Conversation:\n$contextMessages\nAssistant:")
                            messageDao.insert(MessageEntity(conversationId = chatId, fromUser = false, text = reply)); chatDao.touch(chatId)
                        } catch (e: Exception) { error = e.message ?: "Request failed. Please try again." } finally { loading = false }
                    }
                }) { Icon(Icons.Default.Send, "Send", tint = Blue) }
            }
        }
    }
    renameTarget?.let { target ->
        AlertDialog(onDismissRequest = { renameTarget = null }, containerColor = CardDark, title = { Text("Rename conversation", color = TextMain) }, text = { OutlinedTextField(renameText, { renameText = it }, singleLine = true, label = { Text("Conversation name") }) }, confirmButton = { TextButton(onClick = { val name = renameText.trim(); if (name.isNotEmpty()) scope.launch { chatDao.rename(target.id, name) }; renameTarget = null }) { Text("Save", color = Blue) }, dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Cancel", color = Muted) } })
    }
}



@Composable
private fun MemoryVaultScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val dao = remember { AuraDatabase.get(context).memoryDao() }
    val memories by dao.observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var entry by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Navy).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Memory Vault", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Save only what you want AURA to remember. Stored locally on this device.", color = Muted)
        OutlinedTextField(entry, { entry = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Add a memory…") }, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextMain, unfocusedTextColor = TextMain))
        Button(onClick = { val text = entry.trim(); if (text.isNotEmpty()) { scope.launch { dao.insert(MemoryEntity(text = text)) }; entry = "" } }, enabled = entry.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text("Save memory") }
        if (memories.isEmpty()) Text("No saved memories yet.", color = Muted)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(memories, key = { it.id }) { memory ->
            Row(Modifier.fillMaxWidth().background(CardDark, RoundedCornerShape(16.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(memory.text, color = TextMain, modifier = Modifier.weight(1f))
                IconButton(onClick = { scope.launch { dao.delete(memory) } }) { Icon(Icons.Default.Delete, "Delete memory", tint = Muted) }
            }
        } }
        if (memories.isNotEmpty()) TextButton(onClick = { scope.launch { dao.clear() } }) { Text("Clear all memories", color = Color(0xFFFF9292)) }
    }
}


@Composable
private fun ProjectsScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val dao = remember { AuraDatabase.get(context).projectDao() }
    val projects by dao.observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Navy).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Projects", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Keep related ideas organized in one place.", color = Muted)
        OutlinedTextField(name, { name = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Project name") }, singleLine = true)
        OutlinedTextField(desc, { desc = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Description (optional)") }, maxLines = 3)
        Button(onClick = { val n = name.trim(); if (n.isNotEmpty()) { scope.launch { dao.insert(ProjectEntity(name = n, description = desc.trim())) }; name = ""; desc = "" } }, enabled = name.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text("Create project") }
        if (projects.isEmpty()) Text("Your projects will appear here.", color = Muted)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(projects, key = { it.id }) { project ->
            Row(Modifier.fillMaxWidth().background(CardDark, RoundedCornerShape(16.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(project.name, color = TextMain, fontWeight = FontWeight.SemiBold); if (project.description.isNotBlank()) Text(project.description, color = Muted, fontSize = 12.sp) }
                IconButton(onClick = { scope.launch { dao.delete(project) } }) { Icon(Icons.Default.Delete, "Delete project", tint = Muted) }
            }
        } }
    }
}


@Composable
private fun TaskPlannerScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val dao = remember { AuraDatabase.get(context).taskDao() }
    val tasks by dao.observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Navy).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("TASK PLANNER", color = Teal, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text("Tasks", color = TextMain, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Keep your next steps in one place. Tasks are stored locally.", color = Muted)
        OutlinedTextField(title, { title = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Task title") })
        OutlinedTextField(detail, { detail = it }, modifier = Modifier.fillMaxWidth(), maxLines = 3, placeholder = { Text("Details (optional)") })
        Button(onClick = { val t = title.trim(); if (t.isNotEmpty()) { scope.launch { dao.insert(TaskEntity(title = t, detail = detail.trim())) }; title = "" ; detail = "" } }, enabled = title.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text("Add task") }
        if (tasks.isEmpty()) Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { Text("No tasks yet. Add your first task above.", color = Muted) }
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tasks, key = { it.id }) { task ->
                Row(Modifier.fillMaxWidth().background(CardDark, RoundedCornerShape(16.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = task.completed, onCheckedChange = { checked -> scope.launch { dao.setCompleted(task.id, checked) } })
                    Column(Modifier.weight(1f)) { Text(task.title, color = TextMain, fontWeight = FontWeight.Medium); if (task.detail.isNotBlank()) Text(task.detail, color = Muted, fontSize = 12.sp) }
                    IconButton(onClick = { scope.launch { dao.delete(task) } }) { Icon(Icons.Default.Delete, "Delete task", tint = Muted) }
                }
            }
        }
    }
}

@Composable
private fun SimpleScreen(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onSettings: (() -> Unit)? = null) {
    Column(Modifier.fillMaxSize().background(Navy).padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp), horizontalAlignment = Alignment.Start) {
        Icon(icon, null, tint = Blue, modifier = Modifier.size(36.dp)); Text(title, color = TextMain, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text(description, color = Muted)
        onSettings?.let { Button(onClick = it, colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text("Open settings") } }
    }
}
