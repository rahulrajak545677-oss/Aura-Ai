package com.auraai.app.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.setContent
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.auraai.app.network.GeminiClient
import kotlinx.coroutines.launch

private val BubbleNavy = Color(0xFF080D18)
private val BubbleSurface = Color(0xFF101827)
private val BubbleCard = Color(0xFF172234)
private val BubbleBlue = Color(0xFF299BFF)
private val BubbleTeal = Color(0xFF43DCC5)
private val BubbleText = Color(0xFFF3F6FC)
private val BubbleMuted = Color(0xFF98A7BC)

class FloatingAssistantService : Service() {
    private lateinit var wm: WindowManager
    private var bubbleView: ComposeView? = null
    private var miniView: ComposeView? = null
    private var showingMini = false
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var miniParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(42, notification())
        showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    private fun showBubble() {
        if (bubbleView != null || !android.provider.Settings.canDrawOverlays(this)) return
        val prefs = getSharedPreferences("aura_overlay", MODE_PRIVATE)
        val view = ComposeView(this).apply {
            setContent {
                MaterialTheme(colorScheme = darkColorScheme(primary = BubbleBlue, background = BubbleNavy, surface = BubbleSurface)) {
                    Box(Modifier.size(58.dp).background(BubbleNavy, CircleShape), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(54.dp).background(BubbleCard, CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = "Open AURA mini chat", tint = BubbleBlue, modifier = Modifier.size(30.dp))
                        }
                    }
                }
            }
        }
        val params = WindowManager.LayoutParams(
            dp(62), dp(62),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", 30)
            y = prefs.getInt("y", 300)
        }
        view.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0; private var moved = false
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; moved = false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - downX).toInt(); val dy = (event.rawY - downY).toInt()
                        if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 8) moved = true
                        params.x = startX + dx; params.y = startY + dy
                        try { wm.updateViewLayout(view, params) } catch (_: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) openMiniChat()
                        else {
                            val screenWidth = resources.displayMetrics.widthPixels
                            params.x = if (params.x + dp(30) < screenWidth / 2) dp(8) else screenWidth - dp(70)
                            try { wm.updateViewLayout(view, params) } catch (_: Exception) {}
                            prefs.edit().putInt("x", params.x).putInt("y", params.y).apply()
                        }
                        return true
                    }
                }
                return true
            }
        })
        try { wm.addView(view, params); bubbleView = view; bubbleParams = params } catch (_: Exception) { bubbleView = null }
    }


    private fun openMiniChat() {
        if (showingMini || !android.provider.Settings.canDrawOverlays(this)) return
        showingMini = true
        bubbleView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubbleView = null
        val view = ComposeView(this).apply {
            setContent {
                MiniChatOverlay(
                    onClose = { closeMiniChat() },
                    onExpand = {
                        closeMiniChat()
                        val launch = packageManager.getLaunchIntentForPackage(packageName)
                        launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(launch)
                    }
                )
            }
        }
        val params = WindowManager.LayoutParams(
            dp(330), dp(460),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(12); y = dp(90) }
        try { wm.addView(view, params); miniView = view; miniParams = params } catch (_: Exception) { showingMini = false; showBubble() }
    }

    private fun closeMiniChat() {
        miniView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        miniView = null; miniParams = null; showingMini = false
        showBubble()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("aura_overlay", "AURA floating assistant", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun notification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "aura_overlay") else Notification.Builder(this)
        return builder.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("AURA floating assistant is active").setContentText("Tap the floating bubble to open mini chat").setOngoing(true).build()
    }
    override fun onDestroy() {
        bubbleView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        miniView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubbleView = null; miniView = null; showingMini = false
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
    companion object { const val ACTION_STOP = "com.auraai.app.overlay.STOP" }
}


@Composable
private fun MiniChatOverlay(onClose: () -> Unit, onExpand: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("aura_prefs", Context.MODE_PRIVATE) }
    val apiKey = remember { prefs.getString("gemini_key", "") ?: "" }
    val client = remember { GeminiClient() }
    val chat = remember { mutableStateListOf<Pair<Boolean, String>>() }
    var input by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(BubbleNavy, RoundedCornerShape(26.dp))) {
        Row(Modifier.fillMaxWidth().background(BubbleSurface, RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AutoAwesome, null, tint = BubbleBlue)
            Spacer(Modifier.width(8.dp)); Text("AURA AI", color = BubbleText, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onExpand) { Icon(Icons.Default.ExpandLess, "Open full app", tint = BubbleMuted) }
            IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close mini chat", tint = BubbleMuted) }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (chat.isEmpty()) item { Text("Ask anything. AURA is ready.", color = BubbleMuted, fontSize = 13.sp) }
            items(chat) { message ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.first) Arrangement.End else Arrangement.Start) {
                    Text(message.second, color = BubbleText, fontSize = 14.sp, modifier = Modifier.widthIn(max = 250.dp).background(if (message.first) Color(0xFF193B60) else BubbleCard, RoundedCornerShape(16.dp)).padding(11.dp))
                }
            }
            if (isLoading) item { Text("Thinking…", color = BubbleTeal, fontSize = 13.sp) }
            if (error.isNotBlank()) item { Text(error, color = Color(0xFFFFA8A8), fontSize = 12.sp) }
        }
        Row(Modifier.fillMaxWidth().background(BubbleSurface, RoundedCornerShape(bottomStart = 26.dp, bottomEnd = 26.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Message…", color = BubbleMuted) }, maxLines = 3, colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color.Transparent, focusedBorderColor = BubbleBlue, unfocusedTextColor = BubbleText, focusedTextColor = BubbleText))
            IconButton(enabled = !isLoading && input.isNotBlank(), onClick = {
                val prompt = input.trim(); input = ""; chat.add(true to prompt); error = ""; isLoading = true
                scope.launch { try { chat.add(false to client.reply(apiKey, prompt)) } catch (e: Exception) { error = e.message ?: "Request failed. Try again." } finally { isLoading = false } }
            }) { Icon(Icons.Default.Send, "Send", tint = BubbleBlue) }
        }
    }
}
