import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || false }));
app.use(express.json({ limit: '8mb' }));
app.use(rateLimit({ windowMs: 60_000, limit: 40, standardHeaders: true, legacyHeaders: false }));

const port = Number(process.env.PORT || 8787);
const authToken = process.env.API_TOKEN || '';
const requireAuth = (req, res, next) => {
  if (!authToken) return res.status(503).json({ error: 'Server API_TOKEN is not configured.' });
  const supplied = req.header('authorization') || '';
  if (supplied !== `Bearer ${authToken}`) return res.status(401).json({ error: 'Unauthorized.' });
  next();
};

const sys = `You are AURA, a calm, thoughtful, practical AI assistant. Be warm and respectful without claiming human feelings, consciousness, or personal experiences. Adapt answer length to the request. Never reveal hidden reasoning; provide concise explanations and conclusions. Be transparent about uncertainty and tools. Do not fabricate live research, citations, or capabilities.`;

async function fetchWithTimeout(url, options, ms = 35_000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  try { return await fetch(url, { ...options, signal: controller.signal }); }
  finally { clearTimeout(timer); }
}
async function callGemini(messages) {
  const key = process.env.GEMINI_API_KEY; if (!key) throw new Error('Gemini key not configured');
  const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
  const contents = messages.filter(m => m.role !== 'system').map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: String(m.content ?? '') }] }));
  const response = await fetchWithTimeout(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`, {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ systemInstruction: { parts: [{ text: sys }] }, contents, generationConfig: { temperature: 0.7 } })
  });
  const body = await response.json(); if (!response.ok) throw new Error(body?.error?.message || `Gemini error ${response.status}`);
  return body?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('') || 'The provider returned an empty response.';
}
async function callCompat(provider, messages) {
  let base, key, model;
  if (provider === 'groq') { base = 'https://api.groq.com/openai/v1'; key = process.env.GROQ_API_KEY; model = process.env.GROQ_MODEL || 'llama-3.3-70b-versatile'; }
  else { base = 'https://openrouter.ai/api/v1'; key = process.env.OPENROUTER_API_KEY; model = process.env.OPENROUTER_MODEL; }
  if (!key || !model) throw new Error(`${provider} API key/model not configured`);
  const response = await fetchWithTimeout(`${base}/chat/completions`, { method: 'POST', headers: { authorization: `Bearer ${key}`, 'content-type': 'application/json' }, body: JSON.stringify({ model, messages: [{ role: 'system', content: sys }, ...messages.map(m => ({ role: m.role, content: String(m.content ?? '') }))], temperature: 0.7 }) });
  const body = await response.json(); if (!response.ok) throw new Error(body?.error?.message || `${provider} error ${response.status}`);
  return body?.choices?.[0]?.message?.content || 'The provider returned an empty response.';
}
app.get('/health', (_req, res) => res.json({ ok: true, service: 'aura-api', providerConfigured: ['gemini','groq','openrouter'].filter(p => p === 'gemini' ? !!process.env.GEMINI_API_KEY : p === 'groq' ? !!process.env.GROQ_API_KEY : !!process.env.OPENROUTER_API_KEY) }));
app.post('/v1/chat', requireAuth, async (req, res) => {
  const { messages, provider } = req.body || {};
  if (!Array.isArray(messages) || !messages.length || messages.length > 40) return res.status(400).json({ error: 'messages must be a non-empty array (max 40).' });
  if (messages.some(m => !['user','assistant','system'].includes(m?.role) || typeof m.content !== 'string' || m.content.length > 40_000)) return res.status(400).json({ error: 'Invalid message format or message too long.' });
  const chosen = provider || process.env.DEFAULT_PROVIDER || 'gemini';
  const providers = chosen === 'auto' ? ['gemini','groq','openrouter'] : [chosen];
  const errors = [];
  for (const p of providers) {
    try { const text = p === 'gemini' ? await callGemini(messages) : await callCompat(p, messages); return res.json({ text, provider: p }); }
    catch (e) { errors.push(`${p}: ${e.message}`); }
  }
  res.status(502).json({ error: 'All selected providers failed.', details: errors });
});
app.post('/v1/search', requireAuth, async (req, res) => {
  const query = String(req.body?.query || '').trim(); if (!query || query.length > 500) return res.status(400).json({ error: 'query required (max 500 chars)' });
  const key = process.env.BRAVE_SEARCH_API_KEY; if (!key) return res.status(503).json({ error: 'Brave Search is not configured on this server.' });
  try {
    const url = `https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=8`;
    const r = await fetchWithTimeout(url, { headers: { 'X-Subscription-Token': key, accept: 'application/json' } });
    const data = await r.json(); if (!r.ok) return res.status(r.status).json({ error: data?.message || 'Search provider error.' });
    res.json({ query, results: (data.web?.results || []).map(x => ({ title: x.title, description: x.description, url: x.url })).filter(x => /^https:\/\//.test(x.url)) });
  } catch (e) { res.status(502).json({ error: e.message || 'Search request failed.' }); }
});
app.post('/v1/image', requireAuth, async (req, res) => {
  const prompt = String(req.body?.prompt || '').trim();
  if (!prompt || prompt.length > 4000) return res.status(400).json({ error: 'prompt required (max 4000 chars)' });
  const endpoint = process.env.IMAGE_API_URL, key = process.env.IMAGE_API_KEY, model = process.env.IMAGE_MODEL;
  if (!endpoint || !key || !model) return res.status(501).json({ error: 'Image generation provider is not configured. Set a verified provider endpoint, key, and model on the backend.' });
  res.status(501).json({ error: 'Image provider adapter is intentionally not assumed compatible. Implement and test the provider-specific request/response schema before enabling it.' });
});
app.listen(port, () => console.log(`AURA API listening on ${port}`));
