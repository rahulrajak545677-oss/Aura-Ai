# AURA backend proxy (development starter)

This Node/Express backend keeps provider keys out of the Android client. It provides:
- `GET /health`
- `POST /v1/chat` (Gemini, Groq, OpenRouter; provider `auto` attempts them in order)
- `POST /v1/search` (Brave Search)
- `POST /v1/image` (deliberately reports setup limitation until a verified image provider adapter is implemented)

## Setup
1. Install Node.js 20+.
2. Copy `.env.example` to `.env` and fill keys. Create a long random `API_TOKEN`.
3. `npm install`
4. `npm run start`
5. Android clients should call your HTTPS deployment and send `Authorization: Bearer <API_TOKEN>`.

**Security:** this is a starter proxy, not production-ready. Do not expose it publicly without TLS, a proper per-user authentication system, usage quotas, abuse protection, secrets management, and privacy-conscious logging. A bearer token shared in an APK is extractable; use a user-authenticated backend token flow for a public release. CORS is restricted by default. Keep `.env` out of version control.

Provider names: `gemini`, `groq`, `openrouter`, `auto`. Chat payload is `{ "provider": "gemini", "messages": [{ "role": "user", "content": "..." }] }`.
