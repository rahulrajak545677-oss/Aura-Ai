# AURA AI — Android + API bundle

**Tagline:** Think. Understand. Create. Assist.
Dark navy/graphite UI with electric blue and teal accents. Native Android app written in Kotlin + Jetpack Compose, with local Room persistence and an optional backend proxy.

## Folder map
- `app/`: Android application source
- `backend/`: Node/Express provider proxy starter
- `docs/`: honest status and release checklist

## GitHub setup and Android build

This repository is prepared for GitHub development and includes a CI workflow at `.github/workflows/android-ci.yml`.


### Build locally
- Install JDK 17 and Android Studio with Android SDK Platform 35.
- Open the repository root (`AuraAI/`) in Android Studio and sync Gradle.
- Or install Gradle 8.9 and run `gradle assembleDebug` from the repository root.
- The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

**Note:** Gradle Wrapper files are not included yet. Local command-line builds therefore require Gradle installed. GitHub Actions installs Gradle 8.9 for the build job. Android compilation has not yet been verified in this packaging environment.

### GitHub Actions
On pushes and pull requests to `main`/`master`, the workflow compiles the debug APK and syntax-checks the backend. If the Android build succeeds, download the `aura-ai-debug-apk` artifact from the workflow run's Artifacts section (retained for 7 days).

## Development API keys
The current Android client has development-only direct API key entry for Gemini and Brave. Direct keys saved in a distributed APK are not secure. For release, migrate Android networking to the backend, deploy it with HTTPS and real user authentication, and do not embed shared provider keys.

## Backend
See `backend/README.md`. It supports Gemini, Groq, OpenRouter chat and Brave search through authenticated routes. Image endpoint is intentionally disabled until a real provider and API schema are selected.

## Included Android data
Room includes conversation/messages, memories, projects, tasks, saved asset metadata, and project notes. Task/saved-asset/project-note database access is present; all user-facing screens and background scheduling for those modules are not yet integrated.

## Important: this is a development source bundle
It is not a completed app with every requested feature. See `docs/FEATURE_STATUS_AND_RELEASE_CHECKLIST.md` for exact implemented vs incomplete modules. Do not treat earlier build claims as device-verified: compilation, overlay behavior, and API runtime tests remain outstanding.

### Task planner
Home includes a Tasks shortcut to a local Room-backed task list. It supports creating a task with optional details, marking complete, and deleting. Due dates/reminders are not yet connected.
