# Contributing

1. Fork the repository and create a feature branch.
2. Keep provider secrets out of source control. Use `backend/.env.example` as a template only.
3. Run backend syntax checks with `node --check backend/src/server.js`.
4. Build the Android app with Gradle 8.9 and JDK 17: `gradle assembleDebug` from the repository root (or use Android Studio).
5. Open a pull request with a clear description and test notes. Do not claim features are tested on-device unless they were.
