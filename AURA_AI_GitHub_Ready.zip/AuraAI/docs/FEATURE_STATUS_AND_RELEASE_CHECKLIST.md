# AURA AI Complete Bundle — honest feature status

This ZIP is a broad development bundle, not a finished production APK. Android compilation and device tests have not been run in this environment.

## Included source
- Native Android app source: Kotlin, Compose, Material 3, Room
- Home/navigation, chat UI, Gemini client, local memories/projects/chat history source
- Voice UI source using Android speech recognition/TTS
- Floating bubble/mini-chat overlay service source (requires user overlay permission)
- Brave search client/UI source (requires Brave key)
- Room v3 data layer: tasks, saved asset metadata, project notes DAOs and migration
- Backend starter with server-side Gemini/Groq/OpenRouter keys and Brave search
- API route for image generation that clearly reports not configured, rather than returning fake output
- Configuration examples, architecture docs, security notes

## Not finished / not verified
- No Android APK built; Kotlin/Gradle compile is unverified.
- Floating service is not device-tested and Android OEM background restrictions may affect it.
- Task, saved-assets, and project-note data models/DAOs are present; complete end-user screens and notifications are not integrated.
- API proxy routes are not wired into the Android Retrofit clients. Android currently contains development direct-provider adapters.
- Provider fallback in the backend is basic sequential failover, not smart task classification or streaming.
- Web search UI/client uses direct Brave development credentials; backend route exists but Android is not switched to it.
- Image generation is intentionally not enabled: no image provider has been selected/verified and no fake generator is provided.
- File parsing (PDF/DOCX), camera/screenshot workflows, notification task scheduling, comprehensive search across app data, streaming, per-user auth, and production key protection remain incomplete.
- TinyFish adapter is not included because no verified API contract/credentials were supplied.

## Build verification checklist
1. Open `AuraAI/` in Android Studio with SDK 35 installed.
2. Sync dependencies and compile; fix any issues first.
3. Test chat using a development Gemini key.
4. Test search using Brave key.
5. Test microphone flow and TTS on device.
6. Test overlay permission, drag, edge placement, close, and restart on multiple OEMs.
7. Verify Room migrations from version 1 and version 2 database states.
8. Run lint, dependency checks, and security review.
9. Deploy backend behind HTTPS with secrets and user auth; never ship provider secrets in APK.
10. Configure a verified image provider and implement its provider-specific adapter before enabling generation.

## Task planner addition (bundle refresh)
- Added a local task planner screen reachable from the Home quick-action row.
- Supports task title/details, persistent create, completion toggle, and deletion through Room.
- Due dates, reminder scheduling, and notifications remain unimplemented.
