# Security policy

## Reporting a vulnerability
Please do not report security vulnerabilities in public issues. Contact the repository maintainer privately using GitHub's private vulnerability reporting feature, if enabled.


## API secrets
- Never commit `.env`, API keys, tokens, passwords, or signing files.
- Use backend environment variables for provider credentials.
- Do not distribute a shared bearer token or provider API key in an APK; it can be extracted.
- The backend in this repository is a development starter. Before public deployment, add user authentication, per-user quotas, abuse controls, TLS, and privacy-safe logging.
